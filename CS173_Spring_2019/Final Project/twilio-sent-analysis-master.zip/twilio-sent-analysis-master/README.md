This material was used in two of my tech tutorials, which you can find below:

[Analyzing Messy Data Sentiment with Python and nltk](https://www.twilio.com/blog/2017/09/sentiment-analysis-python-messy-data-nltk.html)

[Making Sentiment Analysis Easy With Scikit-Learn](https://www.twilio.com/blog/2017/12/sentiment-analysis-scikit-learn.html)
